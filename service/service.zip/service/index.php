<?php

header("location: landing.php");