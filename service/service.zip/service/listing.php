<?php 

$names = urldecode($_GET['name']);

// disini di list array data sub.nya
$list_data_operate = [
                [
                  'pict' => '',
                  'title' =>'Start-Up Services & Extended Warranty Protection',
                  'desc_info' => '',
                ],
                [
                  'pict' => '',
                  'title' =>'Preventive & Predictive Maintenance',
                  'desc_info' => '',
                ],
                [
                  'pict' => '',
                  'title' =>'BluEdge™ Digital',
                  'desc_info' => '',
                ],
                [
                  'pict' => '',
                  'title' =>'Remote Airside Management',
                  'desc_info' => '',
                ],
                [
                  'pict' => '',
                  'title' =>'Repairs & Emergency Service',
                  'desc_info' => '',
                ],
                [
                  'pict' => '',
                  'title' =>'Equipment Overhaul',
                  'desc_info' => '',
                ],
                [
                  'pict' => '',
                  'title' =>'Refrigerant Management',
                  'desc_info' => '',
                ],
                [
                  'pict' => '',
                  'title' =>'Temporary Solutions',
                  'desc_info' => '',
                ],
                [
                  'pict' => '',
                  'title' =>'24/7 Support & Service',
                  'desc_info' => '',
                ],
                [
                  'pict' => '',
                  'title' =>'Consulting Engineering',
                  'desc_info' => '',
                ],
                                
              ];

?>

<?php include '../includes/_header.php'; ?>
<main class="header-static-margin">
  <div class="container-fluid bg-light position-static-breadcrumb">
    <div class="container ct-header-basic-submenu">
      <nav class="ct-menusub-basic navbar navbar-expand navbar-light">
        <ul class="ct-menusub-basic-header navbar-nav mr-auto">
          <li class="nav-item ">
            <a class="nav-link" href="" target="_self">Service Overview</a>
          </li>
          <li class="nav-item  active">
            <a class="nav-link" href="" target="_self">Operate, Service &amp; Protect</a>
          </li>
          <li class="nav-item ">
            <a class="nav-link" href="" target="_self">Retrofit &amp;
              Optimize</a>
          </li>
          <li class="nav-item ">
            <a class="nav-link" href="" target="_self">Request
              Information</a>
          </li>
          <li class="nav-item ">
            <a class="nav-link" href="tel:800-379-6484" target="_self">Contact Us: 800-379-6484</a>
          </li>
        </ul>
      </nav>
    </div>
  </div>
  <section id="main-content" class="pt-one-col">
    <div class="container-fluid ct-breadcrumb-a">
      <div class="container">
        <nav class="ct_breadcrumb-a d-none d-md-block" aria-label="breadcrumb">
          <ol class="breadcrumb" itemscope itemtype="http://schema.org/BreadcrumbList">
            <li class="breadcrumb-item" itemprop="itemListElement" itemscope itemtype="http://schema.org/ListItem">
              <span id="breadcrumb(1)" itemprop="name">
                <a itemprop="item" href="../../index.html">
                  Home
                </a>
                <span content="Home" itemprop="name" aria-hidden="true"></span>
              </span>
              <meta itemprop="position" content="1" />
            </li>
            <li class="breadcrumb-item" itemprop="itemListElement" itemscope itemtype="http://schema.org/ListItem">
              <span itemprop="name" id="breadcrumb(2)">
                <a itemprop="item" href="../index.html">
                  Service
                </a>
                <span content="Service" itemprop="name" aria-hidden="true"></span>
              </span>
              <meta itemprop="position" content="2" />
            </li>
            <li class="breadcrumb-item" itemprop="itemListElement" itemscope itemtype="http://schema.org/ListItem">
              <span itemprop="name" id="breadcrumb(3)">Operate, Service & Protect</span>
              <meta itemprop="position" content="3" />
            </li>
          </ol>
        </nav>
        <nav class="ct_breadcrumb-b d-block d-md-none" aria-label="breadcrumb">
          <ol class="breadcrumb">
            <li class="breadcrumb-item active">
              <i class="material-icons align-bottom">keyboard_arrow_left<span class="sr-only">Arrow
                  back</span></i>
              <a href="../index.html">
                <span>Service</span>
              </a>
            </li>
          </ol>
        </nav>
      </div>
    </div>
    <div class="container-fluid p-0 ct-hero-img">
      <div class="">
        <div class="d-flex h-100 justify-content-center align-items-center hero-img">
          <img class="cld-responsive bg-secondary" src="https://via.placeholder.com/1920x300.png?text=img" alt="carrier-group-of-highrise-buildings-in-city-looking-up" loading="lazy" />
          <div class="cld-responsive bg-secondary">

          </div>
        </div>
      </div>
      <div class="container position-relative p-0 ">
        <div class="position-absolute bg-transparent-primary w-100 p-3 text-white hero-title">
          <h1>Your HVAC equipment is a critical asset to your building and is worth protecting</h1>
        </div>
      </div>
    </div>
    <div class="container border border-top-0 p-3 hero-text">
      <p>Carrier's expansive knowledge of this equipment is the basis for our portfolio of services.
        Individually and collectively, this knowledge is the best platform from which to operate
        equipment efficiently, safely and predictably.</p>
    </div>
    </div>
    <section class="container ct-card-collection-w3-18">
      <div class="row">
        <div class="col-12 text-center">
        </div>
      </div>
      <div class="row">
        <?php foreach ($list_data_operate as $key => $value){ ?>
        <div class="col-md-4 mb-3 card-container">
          <div class="card h-100 text-left">
            <img class="cld-responsive card-img-top" src="https://images.carriercms.com/image/upload/h_200,c_fit,q_auto,f_auto/v1574436306/carrier/commercial-hvac/products/chillers/carrier-chiller-in-industrial-setting-card-version.jpg" alt="<?php echo $value['title'] ?>" loading="lazy" />
            <div class="card-body">
              <div class="card-title h3"><?php echo $value['title'] ?></div>
              <div class="card-text">Carrier commercial equipment represents today’s most advanced
                technology. To ensure that you receive the full benefits from this leading edge
                design, proper start-up, following a rigorous, factory-defined set of procedures is
                essential.</div>
            </div>
            <div class="card-footer border-0 bg-transparent text-right">
              <a class="btn" href="detail.php?name=<?php echo urlencode($value['title']); ?>" target="_self" aria-label="">
                Learn more
              </a>
            </div>
          </div>
        </div>
        <?php } ?>

      </div>
      <div class="py-3"></div>

    </section>
  </section>
</main>
<?php include '../includes/_footer.php'; ?>